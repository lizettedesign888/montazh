#!/usr/bin/env python3
"""Субтитры «как у блогеров»: по одному слову, крупно, с мягкой тенью.

python3 subtitles.py <видео> <результат.mp4> [--words 1] [--model small] [--color FFFFFF] [--pos 0.68]
"""
import argparse, json, os, subprocess, sys
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
FONTS = os.path.join(HERE, "..", "fonts")


def probe(path):
    out = subprocess.run(["ffprobe", "-v", "error", "-select_streams", "v:0", "-show_entries",
                          "stream=width,height,color_transfer:stream_side_data=rotation",
                          "-of", "json", path], capture_output=True, text=True, check=True).stdout
    s = json.loads(out)["streams"][0]
    w, h = int(s["width"]), int(s["height"])
    rot = 0
    for sd in s.get("side_data_list", []) or []:
        rot = int(sd.get("rotation", 0) or 0)
    if abs(rot) == 90:
        w, h = h, w
    return w, h, s.get("color_transfer", "")


def transcribe(path, model_name):
    from faster_whisper import WhisperModel
    raw = subprocess.run(["ffmpeg", "-v", "error", "-i", path, "-vn", "-ac", "1", "-ar", "16000",
                          "-f", "s16le", "-"], capture_output=True, check=True).stdout
    audio = np.frombuffer(raw, np.int16).astype(np.float32) / 32768
    model = WhisperModel(model_name, device="cpu", compute_type="int8")
    segs, info = model.transcribe(audio, word_timestamps=True, vad_filter=True)
    words = []
    for s in segs:
        for w in s.words:
            t = w.word.strip()
            if t:
                words.append({"text": t, "start": w.start, "end": w.end})
    return words, info.language


def ts(sec):
    sec = max(0, sec)
    h = int(sec // 3600); m = int(sec % 3600 // 60); s = sec % 60
    return f"{h}:{m:02d}:{s:05.2f}"


def chunks(words, n):
    out = []
    i = 0
    while i < len(words):
        group = words[i:i + n]
        # короткие предлоги не оставляем в одиночестве: «в», «на», «и»
        while n == 1 and len(group[-1]["text"].strip(".,!?…«»\"")) <= 2 and i + len(group) < len(words) and len(group) < 2:
            group = words[i:i + len(group) + 1]
        out.append(group)
        i += len(group)
    return out


def build_ass(words, w, h, n, color, pos):
    size = round(w * 0.085)
    margin_v = round(h * (1 - pos))
    rgb = color.upper().lstrip("#")
    bgr = rgb[4:6] + rgb[2:4] + rgb[0:2]
    head = f"""[Script Info]
ScriptType: v4.00+
PlayResX: {w}
PlayResY: {h}
WrapStyle: 2
ScaledBorderAndShadow: yes

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Word,Inter ExtraBold,{size},&H00{bgr},&H00FFFFFF,&H9A000000,&HB4000000,0,0,0,0,100,100,-1,0,1,{max(2, size // 22)},0,2,60,60,{margin_v},1

[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
"""
    lines = []
    groups = chunks(words, n)
    for k, g in enumerate(groups):
        start = g[0]["start"]
        end = g[-1]["end"]
        if k + 1 < len(groups):
            nxt = groups[k + 1][0]["start"]
            end = nxt if nxt - end < 0.6 else end + 0.15  # без мигания между словами
        text = " ".join(x["text"] for x in g).replace("{", "").replace("}", "")
        anim = r"{\blur3\fscx82\fscy82\t(0,90,\fscx100\fscy100)}"
        lines.append(f"Dialogue: 0,{ts(start)},{ts(end)},Word,,0,0,0,,{anim}{text}")
    return head + "\n".join(lines) + "\n"


def main():
    p = argparse.ArgumentParser()
    p.add_argument("src"); p.add_argument("out")
    p.add_argument("--words", type=int, default=1, help="слов на экране за раз (1–3)")
    p.add_argument("--model", default="small", help="small — быстро, medium — точнее")
    p.add_argument("--color", default="FFFFFF", help="цвет текста, hex")
    p.add_argument("--pos", type=float, default=0.68, help="высота субтитров: 0 — верх, 1 — низ")
    p.add_argument("--ass", help="готовый .ass (после правок текста) — пропустить распознавание")
    a = p.parse_args()

    w, h, transfer = probe(a.src)
    base = os.path.splitext(a.out)[0]
    if a.ass:
        ass_path = a.ass
    else:
        print("распознаю речь…", flush=True)
        words, lang = transcribe(a.src, a.model)
        json.dump(words, open(base + ".words.json", "w"), ensure_ascii=False, indent=1)
        ass_path = base + ".ass"
        open(ass_path, "w", encoding="utf-8").write(build_ass(words, w, h, max(1, min(3, a.words)), a.color, a.pos))
        print(f"слов: {len(words)}, язык: {lang}", flush=True)

    vf = []
    if transfer in ("arib-std-b67", "smpte2084"):  # HDR с iPhone → нормальные цвета
        vf.append("zscale=t=linear:npl=203,format=gbrpf32le,zscale=p=bt709,tonemap=mobius:desat=0,zscale=t=bt709:m=bt709:r=tv,format=yuv420p")
    esc = ass_path.replace("\\", "/").replace(":", r"\:").replace("'", r"\'")
    fdir = os.path.abspath(FONTS).replace(":", r"\:")
    vf.append(f"subtitles='{esc}':fontsdir='{fdir}'")
    print("накладываю субтитры…", flush=True)
    subprocess.run(["ffmpeg", "-y", "-v", "error", "-i", a.src, "-vf", ",".join(vf),
                    "-c:v", "libx264", "-preset", "medium", "-crf", "20", "-pix_fmt", "yuv420p",
                    "-c:a", "aac", "-b:a", "192k", "-movflags", "+faststart", a.out], check=True)
    print("готово:", a.out)


if __name__ == "__main__":
    main()
